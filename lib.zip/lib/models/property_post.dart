import 'package:flutter/material.dart';

class PropertyPost {
  const PropertyPost({
    required this.platform,
    required this.seller,
    required this.age,
    required this.title,
    required this.type,
    required this.deal,
    this.video = false,
    this.height = 130,
    this.color = const Color(0xFF8A7650),
    this.price = '',
    this.location = '',
    this.description = '',
    this.socialUrl = '',
    this.imagePaths = const [],
    this.isUserPost = false,
    this.sellerPhone = '',
    this.area = '',
    this.bedrooms = '',
    this.bathrooms = '',
  });

  final String platform, seller, age, title, type, deal;
  final bool video;
  final double height;
  final Color color;
  final String price, location, description, socialUrl;
  final String sellerPhone, area, bedrooms, bathrooms;
  final List<String> imagePaths;
  final bool isUserPost;

  String get storageKey => '\u001f$platform\u001f$seller\u001f$title';

  /// Extracted seller initials for avatar display
  String get initials {
    final trimmed = seller.trim();
    if (trimmed.isEmpty) return 'P';
    final parts = trimmed.split(RegExp(r'\s+'));
    if (parts.length == 1) return parts[0][0].toUpperCase();
    return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
  }

  /// First segment of location string before comma
  String get shortLocation {
    final trimmed = location.trim();
    if (trimmed.isEmpty) return '';
    final idx = trimmed.indexOf(',');
    return idx == -1 ? trimmed : trimmed.substring(0, idx);
  }

  /// Pre-formatted search string for high-performance filtering
  String get searchableText {
    return '$title $type $deal $seller $platform $location'.toLowerCase();
  }
}
