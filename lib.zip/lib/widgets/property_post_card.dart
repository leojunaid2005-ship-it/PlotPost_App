import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/property_post.dart';
import 'report_post_modal.dart';
import 'static_chip.dart';

class PropertyPostCard extends StatefulWidget {
  const PropertyPostCard({
    super.key,
    required this.post,
    required this.onTap,
    this.isSaved = false,
    this.onToggleSaved,
  });

  final PropertyPost post;
  final VoidCallback onTap;
  final bool isSaved;
  final VoidCallback? onToggleSaved;

  @override
  State<PropertyPostCard> createState() => _PropertyPostCardState();
}

class _PropertyPostCardState extends State<PropertyPostCard> {
  bool _isLiked = false;

  void _showPostOptionsMenu(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (modalContext) => Container(
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF181B22) : theme.colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.4),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 12),
              ListTile(
                leading: const Icon(Icons.copy_rounded, size: 20),
                title: const Text('Copy property details', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
                onTap: () {
                  Navigator.pop(modalContext);
                  final lines = [
                    widget.post.title,
                    'Price: ${widget.post.price.isEmpty ? 'Price on request' : widget.post.price}',
                    'Type: ${widget.post.type} · ${widget.post.deal}',
                    if (widget.post.location.isNotEmpty) 'Location: ${widget.post.location}',
                  ];
                  Clipboard.setData(ClipboardData(text: lines.join('\n')));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Listing details copied to clipboard.')),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.flag_outlined, color: Color(0xFFED4956), size: 20),
                title: const Text('Report this post', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5, color: Color(0xFFED4956))),
                subtitle: const Text('Flag fake, spam, or inappropriate content', style: TextStyle(fontSize: 11)),
                onTap: () {
                  Navigator.pop(modalContext);
                  showReportPostModal(context, widget.post);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final post = widget.post;

    final platformColor = switch (post.platform) {
      'Instagram' => const Color(0xFFE1306C),
      'Facebook' => const Color(0xFF1877F2),
      'YouTube' => const Color(0xFFFF0000),
      _ => theme.colorScheme.primary,
    };

    final shortLoc = post.shortLocation;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: theme.colorScheme.outlineVariant.withValues(alpha: 0.6),
          width: 0.8,
        ),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: widget.onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            // Instagram Card Header
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
              child: Row(
                children: [
                  // Story Ring Avatar
                  Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          platformColor,
                          platformColor.withValues(alpha: 0.7),
                        ],
                      ),
                    ),
                    child: CircleAvatar(
                      radius: 15,
                      backgroundColor: theme.colorScheme.surface,
                      child: Text(
                        post.initials,
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          color: theme.colorScheme.onSurface,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          post.seller,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            height: 1.1,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${post.platform} • ${post.age}${shortLoc.isNotEmpty ? ' • $shortLoc' : ''}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 10.5,
                            color: theme.colorScheme.onSurfaceVariant,
                            height: 1.1,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      Icons.more_horiz_rounded,
                      size: 20,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                    onPressed: () => _showPostOptionsMenu(context),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    tooltip: 'Post options',
                  ),
                ],
              ),
            ),

            // Image / Video Media Box
            SizedBox(
              height: 215,
              width: double.infinity,
              child: Stack(
                children: [
                  Positioned.fill(
                    child: post.imagePaths.isNotEmpty
                        ? Image.file(
                            File(post.imagePaths.first),
                            fit: BoxFit.cover,
                            cacheWidth: 800,
                            errorBuilder: (_, _, _) => Container(
                              color: post.color,
                              child: const Icon(
                                Icons.home_work_outlined,
                                size: 48,
                                color: Colors.white70,
                              ),
                            ),
                          )
                        : Container(
                            color: post.color,
                            child: Center(
                              child: Icon(
                                post.video
                                    ? Icons.play_circle_fill_rounded
                                    : Icons.home_work_outlined,
                                size: 52,
                                color: Colors.white.withValues(alpha: 0.85),
                              ),
                            ),
                          ),
                  ),
                  // Price Tag Badge Overlay
                  if (post.price.isNotEmpty)
                    Positioned(
                      left: 12,
                      bottom: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.78),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          post.price,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),

            // Action Bar (Like, Comment, Share, Bookmark)
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => setState(() => _isLiked = !_isLiked),
                    child: Icon(
                      _isLiked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                      size: 24,
                      color: _isLiked ? const Color(0xFFED4956) : theme.colorScheme.onSurface,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Icon(
                    Icons.chat_bubble_outline_rounded,
                    size: 21,
                    color: theme.colorScheme.onSurface,
                  ),
                  const SizedBox(width: 14),
                  Icon(
                    Icons.send_rounded,
                    size: 20,
                    color: theme.colorScheme.onSurface,
                  ),
                  const Spacer(),
                  if (widget.onToggleSaved != null)
                    GestureDetector(
                      onTap: widget.onToggleSaved,
                      child: Icon(
                        widget.isSaved ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
                        size: 24,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                ],
              ),
            ),

            // Title, Caption & Tags
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(
                          text: '${post.seller} ',
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        TextSpan(
                          text: post.title,
                          style: TextStyle(
                            fontSize: 13,
                            height: 1.3,
                            color: theme.colorScheme.onSurface,
                          ),
                        ),
                      ],
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      StaticChip(post.type),
                      StaticChip(post.deal),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
