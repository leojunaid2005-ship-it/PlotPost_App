import 'package:flutter/material.dart';
import '../widgets/auth_field.dart';

class AuthFormScreen extends StatelessWidget {
  const AuthFormScreen({super.key, required this.isSignUp, this.forgotPassword = false});
  final bool isSignUp;
  final bool forgotPassword;

  @override
  Widget build(BuildContext context) {
    final title = forgotPassword ? 'Reset password' : (isSignUp ? 'Create account' : 'Welcome back');
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Image.asset(
          'lib/theme/logo.png',
          height: 28,
          fit: BoxFit.contain,
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const SizedBox(height: 28),
            Text(title, textAlign: TextAlign.center,
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.onSurface)),
            const SizedBox(height: 8),
            Text(
              forgotPassword ? 'Enter your email to reset your password.' :
              (isSignUp ? 'Join the PlotPost community.' : 'Log in to your PlotPost account.'),
              textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 13),
            ),
            const SizedBox(height: 32),
            if (isSignUp) ...[
              const AuthField(hint: 'Full name', icon: Icons.person_outline_rounded),
              const SizedBox(height: 12),
            ],
            const AuthField(hint: 'Email address', icon: Icons.email_outlined),
            if (!forgotPassword) ...[
              const SizedBox(height: 12),
              const AuthField(hint: 'Password', icon: Icons.lock_outline_rounded, obscure: true),
            ],
            const SizedBox(height: 22),
            SizedBox(height: 49, child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: Theme.of(context).colorScheme.primary),
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Authentication will be connected in a later step.')),
              ),
              child: Text(forgotPassword ? 'Send reset link' : (isSignUp ? 'Create Account' : 'Log In')),
            )),
          ],
        ),
      ),
    );
  }
}

